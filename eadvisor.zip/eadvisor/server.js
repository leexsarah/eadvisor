//Altered code from http://codeforgeek.com/2014/11/file-uploads-using-node-js/
var express = require('express'),
    multer = require('multer'),
	app = express(),
	done = false;

//Multer
app.use(multer({ dest: '.', rename: function (fieldname, filename) {
		return filename;
	},
	onFileUploadStart: function (file) {
		if(file.extension === "pdf"){
			done = true;
		} else {
			return false;
		}
	}
}));

//Root
app.get('/',function(req,res){
	res.sendFile(__dirname + "/html/form.html");
});

//After file is uploaded
app.post('/uploaded', function(req,res){
  if (done == true){
    res.sendFile(__dirname + "/html/uploaded.html");
	done = false;
  } else {
	  res.sendFile(__dirname + "/html/fail.html");
  }
});

/*Run the server.*/
app.listen(3000, function(){
    console.log("Server is listening on localhost:3000");
});